-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 28, 2010 at 01:11 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cm2`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` int(10) unsigned NOT NULL,
  `cc_id` int(10) unsigned NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `max_student` int(10) unsigned NOT NULL,
  `num_credit` int(10) unsigned NOT NULL,
  `join_open` datetime NOT NULL,
  `join_close` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`ID`, `faculty_id`, `cc_id`, `name`, `description`, `max_student`, `num_credit`, `join_open`, `join_close`) VALUES
(1, 5, 0, 'Khoa học quản lý', 'Môn khoa học quản lý', 20, 4, '2010-10-01 00:00:00', '2010-10-31 00:00:00'),
(3, 6, 0, 'Giáo dục công dân', '', 500, 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 5, 0, 'Phân tích thiết kế hệ thống thông tin', '', 80, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 5, 0, 'Thiết kế giao diện người dùng', '', 70, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 5, 0, 'Thực hành mạng', '', 100, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `courses_catalog`
--

CREATE TABLE IF NOT EXISTS `courses_catalog` (
  `cc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  PRIMARY KEY (`cc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `courses_catalog`
--


-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE IF NOT EXISTS `faculties` (
  `faculty_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`faculty_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `faculties`
--

INSERT INTO `faculties` (`faculty_id`, `name`, `description`) VALUES
(6, 'Điện tử viễn thông', '<a href=''abc''>''abc</a>'),
(5, 'Công nghệ thông tin', ''),
(7, 'Vật lý', ''),
(8, 'Kinh tế', ''),
(15, 'CMD', ''),
(16, 'abcd', ''),
(18, 'Vật lý kỹ thuật', ''),
(20, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `learning`
--

CREATE TABLE IF NOT EXISTS `learning` (
  `course_id` int(10) unsigned NOT NULL,
  `lh_id` int(10) unsigned NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `week_day` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `learning`
--

INSERT INTO `learning` (`course_id`, `lh_id`, `start_time`, `end_time`, `week_day`) VALUES
(1, 3, '00:00:00', '00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `lecture_hall`
--

CREATE TABLE IF NOT EXISTS `lecture_hall` (
  `lh_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`lh_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `lecture_hall`
--

INSERT INTO `lecture_hall` (`lh_id`, `name`, `address`) VALUES
(3, '304 - G2', '');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE IF NOT EXISTS `options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL,
  `option_value` longtext NOT NULL,
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`option_id`, `option_name`, `option_value`) VALUES
(1, 'siteurl', 'http://local.vui360.com/cm2'),
(2, 'template', 'default'),
(3, 'anhlt_selected_courses', ''),
(4, 'tamchec_selected_courses', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` int(10) unsigned NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(128) NOT NULL,
  `full_name` varchar(50) DEFAULT NULL,
  `code` varchar(32) NOT NULL,
  `type` varchar(10) NOT NULL,
  `birthday` date DEFAULT NULL,
  `gender` tinyint(1) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `faculty_id`, `username`, `password`, `full_name`, `code`, `type`, `birthday`, `gender`, `email`, `address`) VALUES
(1, 0, 'admin', '4a31cf71d581d125aa955915265b8db9', NULL, 'AD01', 'admin', NULL, 0, NULL, NULL),
(27, 6, '', '', 'abc', '', 'teacher', '2999-00-00', 1, '', ''),
(34, 5, 'tamchec', 'e10adc3949ba59abbe56e057f20f883e', 'Đỗ Ngọc Tâm', '123456', 'student', '1989-00-00', 1, 'abc@vui360.com', 'a'),
(53, 6, '', '', 'dfnkhfldfjk', '', 'teacher', '0000-00-00', 1, '', ''),
(52, 6, '', '', 'e', '', 'teacher', '0000-00-00', 1, '', ''),
(51, 6, '', '', 'd', '', 'teacher', '0000-00-00', 1, '', ''),
(39, 6, '', '', 'e', '', 'teacher', '0000-00-00', 1, '', ''),
(40, 6, '', '', 'f', '', 'teacher', '0000-00-00', 1, '', ''),
(41, 6, '', '', 'g', '', 'teacher', '0000-00-00', 1, '', ''),
(42, 6, '', '', 'h', '', 'teacher', '0000-00-00', 1, '', ''),
(43, 6, '', '', 'i', '', 'teacher', '0000-00-00', 1, '', ''),
(44, 6, '', '', 'j', '', 'teacher', '0000-00-00', 1, '', ''),
(45, 6, '', '', 'k', '', 'teacher', '0000-00-00', 1, '', ''),
(46, 6, '', '', 'l', '', 'teacher', '0000-00-00', 1, '', ''),
(47, 6, '', '', 'm', '', 'teacher', '0000-00-00', 1, '', ''),
(48, 6, '', '', 'n', '', 'teacher', '0000-00-00', 1, '', ''),
(49, 6, '', '', 'o', '', 'teacher', '0000-00-00', 1, '', ''),
(50, 6, '', '', 'p', '', 'teacher', '0000-00-00', 1, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_join`
--

CREATE TABLE IF NOT EXISTS `users_join` (
  `user_id` bigint(20) unsigned NOT NULL,
  `course_id` int(10) unsigned NOT NULL,
  `mark` float DEFAULT NULL,
  PRIMARY KEY (`user_id`,`course_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_join`
--

INSERT INTO `users_join` (`user_id`, `course_id`, `mark`) VALUES
(27, 0, NULL),
(53, 1, NULL),
(54, 1, NULL),
(27, 4, NULL),
(27, 5, NULL),
(27, 6, NULL),
(54, 5, NULL),
(34, 1, NULL),
(34, 4, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
